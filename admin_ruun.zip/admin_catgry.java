package admin_actions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class admin_catgry {
	WebDriver dr;
	String s,s2;
	String s1;
	//String s2[]={"Categories","Products","Recurring Profiles","Filters,Attributes","Options","Manufacturers","Downloads","Reviews","Information"};;
	By catlg=By.xpath("//*[@id=\"catalog\"]/a");//catlog icon
	By catlgl=By.xpath("//*[@id=\"catalog\"]/ul");//to get full names in the link
	By catgy=By.xpath("//*[@id=\"catalog\"]/ul/li[1]/a");//category
	By catpg=By.xpath("//*[@id=\"content\"]/div[2]/div/div[2]") ;//category page table
	By citm=By.xpath("//*[@id=\"form-category\"]/div/table/tbody/tr[3]/td[1]/input");//check box item
	By cdel=By.xpath("//*[@id=\"content\"]/div[1]/div/div/button");//delete the item
	By ctpgn=By.xpath("//*[@id=\"form-category\"]/div/table/thead/tr/td[2]/a");//category page one value of table
	By ctsuc=By.xpath("//*[@id=\"content\"]/div[2]/div[1]");//success msg
	public admin_catgry(WebDriver dr)
	{
		this.dr=dr;
	    System.out.println(dr);
}
	public String catlog(){
		
	    dr.findElement(catlg).click();
	   // s=dr.findElement(catlgl).getText();
	    s2=dr.findElement(catgy).getText();
	     s1="Categories";
	Assert.assertEquals(s2, s1);
	System.out.println("category pass");
	    return s2;
	}
	public String category(){
		
	    dr.findElement(catgy).click();
	    s=dr.findElement(catpg).getText();
	    s2=dr.findElement(ctpgn).getText();
	    s1="Category Name";
	    Assert.assertEquals(s2, s1);
		System.out.println("categoryname in the page: pass");
	    return s2;
	 }
	public void item_del()
	{
		dr.findElement(citm).click();
		dr.findElement(cdel).click();
		Alert a= dr.switchTo().alert();
		String text=a.getText();
		System.out.println(text);
		a.accept();
		//a.dismiss();
		s2=dr.findElement(ctsuc).getText();
		System.out.println(s2);
		String s3=s2.substring(0,38);
		System.out.println(s3);
		s1="Success: You have modified categories!";
		Assert.assertEquals(s3, s1);
		System.out.println("category item del:passs ");
	}
public void catgry()
{
	catlog();
	category();

}
public void delcat()
{
	catlog();
	category();
	item_del();
}
}
