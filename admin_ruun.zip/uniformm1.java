package admin_actions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class uniformm1 {
	WebDriver dr;
    String s,s1;
	By uname =By.xpath("//*[@id=\"input-username\"]");////*[@id="input-username"]
	By pswd =By.xpath("//*[@id=\"input-password\"]");
	By butn=By.xpath("//*[@id=\"content\"]/div/div/div/div/div[2]/form/div[3]/button");
	
	 public uniformm1(WebDriver dr)
	    {
	    	this.dr=dr;
            System.out.println(dr);
	    }


	 public void ch()
	 {
		   System.setProperty("webdriver.chrome.driver","chromedriver_74.exe");
		 dr = new ChromeDriver();
		dr.get("http://uniformm1.upskills.in/admin");
	 }
		
	   
	 public void set_uname(String un)
	       {
	    	dr.findElement(uname).sendKeys(un);
	    	}
	public void set_password(String pw)
	    {
	 	dr.findElement(pswd).sendKeys(pw);
	 	}
	public void click_butn()
	    {
	 	dr.findElement(butn).click();
	 	}
	    
	  public void admin_login(String u,String p)
	  {
	    //String u="admin";
	    //String p="admin@123";
	    set_uname(u);	
	    set_password(p);
	    this.click_butn();
	   
	    }

}