package STEP_DEFINITIONS;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Test;

import admin_actions.admin_cart;
import admin_actions.admin_catgry;
	import admin_actions.admin_home;
	import admin_actions.admin_prdct;
import admin_actions.admin_prdct1;
import admin_actions.admin_sales;
	import admin_actions.uniformm1;
	import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

	public class ad_login {
		uniformm1 uf;
		admin_catgry ac;
		admin_prdct ap;
		admin_sales as;
		admin_prdct1 ap1;
		admin_cart adct;
		WebDriver dr;
		String s1;
		
@Given("^lauch the chrome browser$")
		public void lauch_the_chrome_browser() throws Throwable
      {
		   System.setProperty("webdriver.chrome.driver","chromedriver_74.exe");
		   dr = new ChromeDriver();
		   dr.get("http://uniformm1.upskills.in/admin");
	 }
		
@When("^login with credentials$")
		public void login_with_credentials() throws Throwable
       {
	         System.out.println(dr);
		     uf=new uniformm1(dr);
		     uf.admin_login("admin","admin@123");
	    }
@Then("^category page$")
		public void sucessful() throws Throwable 
		{
			 System.out.println("successful");
		     ac=new admin_catgry(dr);
			 ac.catgry();
			 System.out.println("scenario1");
		}

@Then("^category deleted$")
		public void category_deleted() throws Throwable
        {
			ac=new admin_catgry(dr);
			ac.delcat();
			System.out.println("scenario2");
	
	    }

@Then("^product page$")
		public void product_page() throws Throwable 
		{
			ap=new admin_prdct(dr);
			ap.product("Blazer-Boys");
			System.out.println("scenario3");
		}

@Then("^Deleting the product$")
		public void deleting_the_product() throws Throwable
        {
			ap=new admin_prdct(dr);
			ap.prddel("blazer");
		    System.out.println("Scenario4");
         }
		
@Then("^checking the status of the sales order$")
		public void checking_the_status_of_the_sales_order() throws Throwable
        {
			as=new admin_sales(dr);
			as.sales("2019-05-02","2019-05-31");
			System.out.println("scenario5");
	     }
@Then("^filtered product$")
		public void filtered_product() throws Throwable
		{
			ap=new admin_prdct(dr);
            ap.prdfilter("Blazer Girls(7-8)", "3000","BLG-112","1100");
            System.out.println(" exp pass-scenario6");
		}
@Then("^Added product in products$")
		public void added_product_in_products() throws Throwable
		{
	         ap1=new admin_prdct1(dr);
             ap1.add_prdct("Girls uniform1", "shirt for girls1", "SHG-0101", "751", "51","new uniforms");
              System.out.println("Scenario 7");
		}	
@Then("^product quantity modified$")
		public void product_quantity_modified() throws Throwable 
		{
			ap1=new admin_prdct1(dr);
			ap1.modify_qty("26");
			System.out.println(" Scenario 8");
		}
@Then("^Admin delete multiple product$")
	        public void Admin_delete_multiple_product() throws Throwable	{
			ap1=new admin_prdct1(dr);
			ap1.prdmuldel( );
            System.out.println("Scenario-9");
		}
@Then("^Generate invoice for the order$")
		public void Generate_invoice_for_the_order() throws Throwable 
		{
			adct=new admin_cart(dr);
            adct.generate_invoice();
            System.out.println("Scenario 10");
		}
}
