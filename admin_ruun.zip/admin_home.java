package admin_actions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class admin_home {
WebDriver dr;
String s;
By catlg=By.xpath("//*[@id=\"catalog\"]/a");
By catlgl=By.xpath("//*[@id=\"catalog\"]/ul");
By catgy=By.xpath("//*[@id=\"catalog\"]/ul/li[1]/a");
By catpg=By.xpath("//*[@id=\"content\"]/div[2]/div/div[2]") ;
By citm=By.xpath("//*[@id=\"form-category\"]/div/table/tbody/tr[3]/td[1]/input");
By cdel=By.xpath("//*[@id=\"content\"]/div[1]/div/div/button");
By prdcat=By.xpath("//*[@id=\"catalog\"]/a/i");
By prdct=By.xpath("//*[@id=\"catalog\"]/ul/li[2]/a");
By prname=By.xpath("//*[@id=\"input-name\"]");
By pfil=By.xpath("//*[@id=\"button-filter\"]");
By pch=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr[1]/td[1]/input");
By pdel=By.xpath("//*[@id=\"content\"]/div[1]/div/div/button[2]");
By sali=By.xpath("//*[@id=\"reports\"]/a/i");
By sale=By.xpath("//*[@id=\"reports\"]/ul/li[1]/a");
By sord=By.xpath("//*[@id=\"reports\"]/ul/li[1]/ul/li[1]/a");
By sordsdt=By.xpath("//*[@id=\"input-date-start\"]");
By sordedt=By.xpath("//*[@id=\"input-date-end\"]");
By sfil=By.xpath("//*[@id=\"button-filter\"]");
By sgby=By.xpath("//*[@id=\"input-group\"]");
By Sos=By.xpath("//*[@id=\"input-status\"]");//*[@id="input-status"]
public admin_home(WebDriver dr)
{
	this.dr=dr;
    System.out.println(dr);
}
public String catlog(){
	
    dr.findElement(catlg).click();
    s=dr.findElement(catlgl).getText();
    return s;
}
public String category(){
	
    dr.findElement(catgy).click();
    String s=dr.findElement(catpg).getText();
    
    return s;
 }
public void item_del()
{
	dr.findElement(citm).click();
	dr.findElement(cdel).click();
	Alert a= dr.switchTo().alert();
	String text=a.getText();
	System.out.println(text);
	//a.accept();
	a.dismiss();
}
public void product()
{
	 dr.findElement(prdcat).click();
	dr.findElement(prdct).click();
	dr.findElement(prname).sendKeys("Blazer-Boys");
	dr.findElement(pfil).click();	
	}
public void prddel()
{
	dr.findElement(prname).clear();
	dr.findElement(prname).sendKeys("blazer");
	dr.findElement(pfil).click();		
	dr.findElement(pch).click();
	dr.findElement(pdel).click();
	Alert a=dr.switchTo().alert();
	//a.accept();
	a.dismiss();
}
public void sales()
{
	dr.findElement(sali).click();
	dr.findElement(sale).click();
	dr.findElement(sord).click();
	dr.findElement(sordsdt).clear();
	dr.findElement(sordsdt).sendKeys("2019-05-02");
	dr.findElement(sordedt).clear();
	dr.findElement(sordedt).sendKeys("2019-05-09");
	//dr.findElement(sfil).click();
WebElement we=dr.findElement(sgby);
Select sel=new Select(we);
sel.selectByIndex(0);
WebElement we1=dr.findElement(Sos);
Select sel1=new Select(we1);
//sel1.selectByValue("pending");
sel1.selectByVisibleText("pending");
dr.findElement(sfil).click();
}

}
