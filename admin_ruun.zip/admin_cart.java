package admin_actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class admin_cart {
WebDriver dr;
String s,s1;
By cart_icon=By.xpath("//*[@id=\"sale\"]/a/i");
By cart_orders=By.xpath("//*[@id=\"sale\"]/ul/li[1]/a");
By view_icon=By.xpath("//*[@id=\"form-order\"]/div/table/tbody/tr[16]/td[8]/a[1]/i");//*[@id="form-order"]/div/table/tbody/tr[7]/td[8]/a[1]/i
By invc_gene=By.xpath("//*[@id=\"button-invoice\"]");//*[@id="button-invoice"]
By invc_num=By.xpath("//*[@id=\"invoice\"]");
//By invc_num=By.xpath("//*[@id=\"content\"]/div[2]/div[3]/div[3]/div/table/tbody/tr[1]");
//By invc_num=By.xpath("//*[contains(text(),'INV')");
public admin_cart( WebDriver dr)
{
this.dr=dr;	
}
public void generate_invoice()
{
	dr.findElement(cart_icon).click();
	
	dr.findElement(cart_orders).click();

	dr.findElement(view_icon).click();
	dr.findElement(invc_gene).click();
	System.out.println("Invoice generated");
	WebDriverWait wt =new WebDriverWait(dr,150);
	wt.until(ExpectedConditions.visibilityOfElementLocated(invc_num));
	s=dr.findElement(invc_num).getText();
	System.out.println("Invoice num:"+s);
	System.out.println(s);
}
}
