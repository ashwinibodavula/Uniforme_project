package admin_actions;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
public class admin_prdct {
	WebDriver dr;
	String s,s1;
	By prdcat=By.xpath("//*[@id=\"catalog\"]/a/i");//Catalog icon
	By prdct=By.xpath("//*[@id=\"catalog\"]/ul/li[2]/a");//product link
	By prname=By.xpath("//*[@id=\"input-name\"]");//product name text box
	By pfil=By.xpath("//*[@id=\"button-filter\"]");//filter button
	By pch=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr[1]/td[1]/input");//check box of 1st product
	By pdel=By.xpath("//*[@id=\"content\"]/div[1]/div/div/button[2]");//product delete icon
	By pfread=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr/td[3]");//reading the filtered value
	By pfread1=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr[1]/td[3]");//reading the first value of table
	By psuc=By.xpath("//*[@id=\"content\"]/div[2]/div[1]");//success msg
	By pprice=By.xpath("//*[@id=\"input-price\"]");//product price
	By pstus=By.xpath("//*[@id=\"input-status\"]");//product status
	By pmdl=By.xpath("//*[@id=\"input-model\"]");//product model
	By pqty=By.xpath("//*[@id=\"input-quantity\"]");//product quantity
	By pline=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr[1]");//filtered line
	By pmdel=By.xpath("//*[@id=\"form-product\"]/div/table/thead/tr/td[1]/input");
	public admin_prdct(WebDriver dr)
	{
		this.dr=dr;
	    System.out.println(dr);
}
	
	public void product(String a)
	{
		 dr.findElement(prdcat).click();
		 s=dr.findElement(prdct).getText();
		dr.findElement(prdct).click();
		System.out.println(s);
		s1="Products";
		Assert.assertEquals(s1, s);
		System.out.println("product link:pass");
	    dr.findElement(prname).sendKeys(a);
		dr.findElement(pfil).click();	
		String s2=dr.findElement(pfread).getText();
		Assert.assertEquals(a, s2);
        System.out.println("filtered value: pass");
	}
	public void prddel(String b)
	{
		dr.findElement(prdcat).click();
		dr.findElement(prdct).click();
		dr.findElement(prname).clear();
		dr.findElement(prname).sendKeys(b);
		dr.findElement(pfil).click();	
		String s1=dr.findElement(pfread1).getText();
		Assert.assertEquals(b, s1);
		dr.findElement(pch).click();
		dr.findElement(pdel).click();
		Alert a=dr.switchTo().alert();
		String text=a.getText();
		System.out.println(text);
		a.accept();
		//a.dismiss();
		s=dr.findElement(psuc).getText();
		String s3=s.substring(0,36);
	System.out.println(s.substring(0,36));
	s1="Success: You have modified products!";
	Assert.assertEquals(s3, s1);
	System.out.println("products item del:passs ");
		dr.findElement(pfil).click();	
	String s2=dr.findElement(pfread1).getText();
         if(s2.equalsIgnoreCase(b))
		{
			System.out.println("fail");
		}
		else
		{
			System.out.println("pass");
		}
	}
public void  prdfilter(String c,String d,String e,String f)
{
	dr.findElement(prdcat).click();
	dr.findElement(prdct).click();
	dr.findElement(prname).clear();
	dr.findElement(prname).sendKeys(c);
	dr.findElement(pfil).click();	
	String s1=dr.findElement(pfread1).getText();
	Assert.assertEquals(c, s1);
	System.out.println("filtered product name");
	dr.findElement(pprice).sendKeys(d);
	String s2="3000";
//	String s2=dr.findElement(pfread1).getText();
//	Assert.assertEquals(d, s2);
//	System.out.println("filtered price");
	WebElement we=dr.findElement(pstus);
	Select sel1=new Select(we);
	sel1.selectByIndex(1);
//	String s3=dr.findElement(pfread1).getText();
//	Assert.assertEquals(c, s3);
//	System.out.println("filtered by status");
//	//*[@id="form-product"]/div/table/tbody/tr[1]
	String s3="Enabled";
	dr.findElement(pmdl).sendKeys(e);
	String s5="BLG-112";
	dr.findElement(pqty).sendKeys(f);
	String s6="1100";
	dr.findElement(pfil).click();
	String s4=dr.findElement(pline).getText();
	if(s4.contains(s2) && s4.contains(s3) && s4.contains(s5)&& s4.contains(s6))
	{
		System.out.println("filtered price");
           if(s4.contains(s3))
	         {
		          System.out.println("filtered by status");
	    	      if(s4.contains(s5))
	    	       {
		                System.out.println("filtered by model");
	    		          if(s4.contains(s6))
	    		            {
	    		        	  		System.out.println("filtered by status");
	    		        	  	    System.out.println("filtered each value: pass");
	                        }
                    }
              }
      }
	else
	{
		System.out.println("fail");
	}
}

}
