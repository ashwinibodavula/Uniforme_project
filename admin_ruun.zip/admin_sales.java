package admin_actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class admin_sales {
	WebDriver dr;
	String s1,s;
	By sali=By.xpath("//*[@id=\"reports\"]/a/i");//sales icon link
	By sale=By.xpath("//*[@id=\"reports\"]/ul/li[1]/a");//sales
	By sord=By.xpath("//*[@id=\"reports\"]/ul/li[1]/ul/li[1]/a");//order
	By sordsdt=By.xpath("//*[@id=\"input-date-start\"]");//start date text box
	By sordedt=By.xpath("//*[@id=\"input-date-end\"]");//end date text box
	By sfil=By.xpath("//*[@id=\"button-filter\"]");//filter
	By sgby=By.xpath("//*[@id=\"input-group\"]");//group by
	By Sos=By.xpath("//*[@id=\"input-status\"]");//*[@id="input-status"] - order status
	By ors=By.xpath("//*[@id=\"content\"]/div[2]/div/div[2]/div[2]/table/tbody/tr");//no of orders
public admin_sales(WebDriver dr)
{
this.dr=dr;	
}
public void saleslnk()
{
	dr.findElement(sali).click();
	dr.findElement(sale).click();
	s=dr.findElement(sord).getText();
	s1="Orders";
	Assert.assertEquals(s, s1);
	System.out.println("sales link: pass");
}
public void ord_link()
{
	dr.findElement(sord).click();
	s=dr.findElement(ors).getText();
	System.out.println(s);
}
public void dates(String sdt,String edt)
{
	dr.findElement(sordsdt).clear();
	dr.findElement(sordsdt).sendKeys(sdt);
	s=dr.findElement(sordsdt).getText();
	//Assert.assertEquals(s,sdt);
	dr.findElement(sordedt).clear();
	dr.findElement(sordedt).sendKeys(edt);
//	WebDriverWait wt=new WebDriverWait(dr,120);
//	wt.until(ExpectedConditions.visibilityOfElementLocated(sordsdt));
//	wt.until(ExpectedConditions.visibilityOfElementLocated(sordedt));
//	s=dr.findElement(sordsdt).getText();
//	s1=dr.findElement(sordedt).getText();
//	Assert.assertEquals(s,sdt);
//	Assert.assertEquals(s1,edt);
	System.out.println("sales date:pass");
}
public void sogroup()
{
	WebElement we=dr.findElement(sgby);
	Select sel=new Select(we);
	sel.selectByIndex(1);
}
public void orst()
{
	WebElement we1=dr.findElement(Sos);
	Select sel1=new Select(we1);
	sel1.selectByVisibleText("Pending");
	dr.findElement(sfil).click();
}
public void sales(String sd,String ed)
{
saleslnk();
ord_link();
dates(sd,ed);
sogroup();
orst();
}
}
