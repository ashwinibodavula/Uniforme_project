package admin_actions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class admin_prdct1 {
	WebDriver dr;
	String s,s1;
	By prdcat=By.xpath("//*[@id=\"catalog\"]/a/i");//Catalog icon
	By prdct=By.xpath("//*[@id=\"catalog\"]/ul/li[2]/a");//product link
	By padd=By.xpath("//*[@id=\"content\"]/div[1]/div/div/a/i");//product add
	By padnam=By.xpath("//*[@id=\"input-name1\"]");//product add name
	By  pmeta=By.xpath("//*[@id=\"input-meta-title1\"]");//product meta tag
	By pdata=By.xpath("//*[@id=\"form-product\"]/ul/li[2]/a");//data link
	By pmodel=By.xpath("//*[@id=\"input-model\"]");//product model
	By paprice=By.xpath("//*[@id=\"input-price\"]");//product add price
	By paqty=By.xpath("//*[@id=\"input-quantity\"]");//product add quantity
	By plink=By.xpath("//*[@id=\"form-product\"]/ul/li[3]/a");//product link
	By pcat=By.xpath("//*[@id=\"input-category\"]");//product category
	By psave=By.xpath("//*[@id=\"content\"]/div[1]/div/div/button");//product save
	By psuc=By.xpath("//*[@id=\"content\"]/div[2]/div[1]");//success msg
	By pedit=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr[1]/td[8]/a");//product edit
	By pdelbb=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr[11]/td[1]/input");//11th line of product
	By pdellb=By.xpath("//*[@id=\"form-product\"]/div/table/tbody/tr[16]/td[1]/input");
	By pdel=By.xpath("//*[@id=\"content\"]/div[1]/div/div/button[2]");//product delete icon
	public admin_prdct1(WebDriver dr)
	{
		this.dr=dr;
	    System.out.println(dr);
    }
	public void add_prdct(String a,String b,String c,String d,String e,String f)
	{
		dr.findElement(prdcat).click();	
		dr.findElement(prdct).click();
		dr.findElement(padd).click();
		dr.findElement(padnam).sendKeys(a);
		dr.findElement(pmeta).sendKeys(b);
		dr.findElement(pdata).click();
		dr.findElement(pmodel).sendKeys(c);
		dr.findElement(paprice).sendKeys(d);
		dr.findElement(paqty).sendKeys(e);
		dr.findElement(plink).click();
		dr.findElement(pcat).sendKeys(f);
		dr.findElement(psave).click();
		suc_msg();
//		s=dr.findElement(psuc).getText();
//		System.out.println(s);
//		String s3=s.substring(0,36);
//        System.out.println(s.substring(0,36));
//         s1="Success: You have modified products!";
//    	Assert.assertEquals(s3, s1);
//	    System.out.println("products item added:passs ");

	}
	public void modify_qty(String a)
	{
		dr.findElement(prdcat).click();	
		dr.findElement(prdct).click();
		dr.findElement(pedit).click();
		dr.findElement(pdata).click();
		dr.findElement(paqty).clear();
		dr.findElement(paqty).sendKeys(a);
		dr.findElement(psave).click();
		suc_msg();
}
	public void suc_msg()
	{
		s=dr.findElement(psuc).getText();
		System.out.println(s);
		String s3=s.substring(0,36);
        System.out.println(s.substring(0,36));
        s1="Success: You have modified products!";
	    Assert.assertEquals(s3, s1);
	    System.out.println("products item :passs ");
    }
	public void prdmuldel( )
	{
		dr.findElement(prdcat).click();
		dr.findElement(prdct).click();
		dr.findElement(pdelbb).click();
		dr.findElement(pdellb).click();
		dr.findElement(pdel).click();
		Alert a=dr.switchTo().alert();
		String text=a.getText();
		System.out.println(text);
		a.accept();
//		a.dismiss();
       suc_msg();
	}
}