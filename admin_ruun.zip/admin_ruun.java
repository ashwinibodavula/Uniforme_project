package Test_Runner;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="Feature",glue={"STEP_DEFINITIONS"},tags={"@smokeTest,@verifyDel,@verifyAdd,@verify" })
public class admin_ruun extends AbstractTestNGCucumberTests {
  
}
